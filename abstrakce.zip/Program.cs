﻿



using System;

namespace MyConsoleApp
{
    interface ITaskManager
    {
        string AddTask();
        string DeleteTask();
        string ViewTask();
    }

    public abstract class TaskManager : ITaskManager
    {
        public abstract string AddTask();
        public abstract string DeleteTask();
        public abstract string ViewTask();
        public abstract void stateTask();
    }

    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
